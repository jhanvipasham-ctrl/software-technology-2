import timeit
import random

# Task 2 - Testing merge sort for different data sizes and benchmarking against insertion sort

def merge_sort(array):
    if len(array) <= 1:
        return array
    else:
        left_split = array[:len(array)//2]
        right_split = array[len(array)//2:]
        left = merge_sort(left_split)
        right = merge_sort(right_split)
        return merge(left, right)

def merge(left, right):
    merged = []
    left_pointer = 0
    right_pointer = 0
    merging = True
    while merging:
        left_element = left[left_pointer]
        right_element = right[right_pointer]
        if left_element < right_element:
            merged.append(left_element)
            left_pointer += 1
        elif right_element < left_element:
            merged.append(right_element)
            right_pointer += 1
        elif right_element == left_element:
            merged.append(right_element)
            merged.append(left_element)
            left_pointer += 1
            right_pointer += 1
        if left_pointer >= len(left):
            merged.extend(right[right_pointer:])
            merging = False
        elif right_pointer >= len(right):
            merged.extend(left[left_pointer:])
            merging = False
    return merged

def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr

# test merge sort for different data sizes
for size in [100, 1000, 5000]:
    test_list = [random.randint(1, 1000) for _ in range(size)]
    sorted_list = merge_sort(test_list[:])
    print(f"Merge sort size {size}: first 5 elements = {sorted_list[:5]}")

# benchmark merge sort vs insertion sort
large_list = [random.randint(1, 1000) for _ in range(1000)]
merge_time = timeit.timeit(lambda: merge_sort(large_list[:]), number=10)
insertion_time = timeit.timeit(lambda: insertion_sort(large_list[:]), number=10)

print(f"\nMerge Sort time:     {merge_time:.6f} seconds")
print(f"Insertion Sort time: {insertion_time:.6f} seconds")
