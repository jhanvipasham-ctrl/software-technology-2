# Task 3 - Tower of Hanoi using recursion

# Part 1 - basic tower of hanoi, showing all moves
def moveDisks(n, fromTower, toTower, auxTower):
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)

print("--- 2 Disks ---")
moveDisks(2, 'A', 'B', 'C')

print("\n--- 3 Disks ---")
moveDisks(3, 'A', 'B', 'C')


# Part 2 - modified to count the total number of moves
move_count = 0

def moveDisksCount(n, fromTower, toTower, auxTower):
    global move_count
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisksCount(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisksCount(n - 1, auxTower, toTower, fromTower)

print("\n--- Counting moves for 2 Disks ---")
move_count = 0
moveDisksCount(2, 'A', 'B', 'C')
print("Total moves for 2 disks:", move_count)

print("\n--- Counting moves for 3 Disks ---")
move_count = 0
moveDisksCount(3, 'A', 'B', 'C')
print("Total moves for 3 disks:", move_count)
