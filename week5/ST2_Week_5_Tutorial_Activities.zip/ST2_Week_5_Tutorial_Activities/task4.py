# Task 4 - Sierpinski Triangle using recursion and Tkinter

from tkinter import *

def drawTriangle(canvas, p1, p2, p3):
    canvas.create_polygon(p1[0], p1[1], p2[0], p2[1], p3[0], p3[1], outline="black", fill="white")

def midpoint(p1, p2):
    return ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)

def sierpinski(canvas, order, p1, p2, p3):
    drawTriangle(canvas, p1, p2, p3)
    if order > 0:
        sierpinski(canvas, order - 1, p1, midpoint(p1, p2), midpoint(p1, p3))
        sierpinski(canvas, order - 1, midpoint(p1, p2), p2, midpoint(p2, p3))
        sierpinski(canvas, order - 1, midpoint(p1, p3), midpoint(p2, p3), p3)

order = 6

window = Tk()
window.title(f"Sierpinski Triangle - Order {order}")
canvas = Canvas(window, width=600, height=600, bg="white")
canvas.pack()

p1 = (300, 20)
p2 = (20, 580)
p3 = (580, 580)

sierpinski(canvas, order, p1, p2, p3)
window.mainloop()
