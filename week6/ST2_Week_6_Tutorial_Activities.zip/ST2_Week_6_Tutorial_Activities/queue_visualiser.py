import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 700
CANVAS_HEIGHT = 200

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = deque()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        push_btn = tk.Button(control_frame, text="Enqueue", command=self.enqueue_value)
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue_value)
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_queue(self):
        self.canvas.delete("all")
        x = 20
        y = 80

        for val in self.queue:
            self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
                                         fill="lightgreen", outline="black", width=2)
            self.canvas.create_text(x + NODE_WIDTH // 2, y + NODE_HEIGHT // 2,
                                    text=str(val), font=("Arial", 16))
            if val != self.queue[-1]:
                self.canvas.create_line(x + NODE_WIDTH, y + NODE_HEIGHT // 2,
                                        x + NODE_WIDTH + HORIZONTAL_GAP,
                                        y + NODE_HEIGHT // 2, arrow=tk.LAST, width=2)
            x += NODE_WIDTH + HORIZONTAL_GAP + 10

        if self.queue:
            self.canvas.create_text(30, 50, text="Front", font=("Arial", 11), fill="red")
            self.canvas.create_text(x - NODE_WIDTH // 2 - 10, 50, text="Rear",
                                    font=("Arial", 11), fill="red")

    def enqueue_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value.")
            return
        self.queue.append(val)
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} to rear of queue")
        self.draw_queue()

    def dequeue_value(self):
        if not self.queue:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = self.queue.popleft()
        self.status_label.config(text=f"Dequeued {val} from front of queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()
