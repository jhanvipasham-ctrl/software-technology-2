from collections import deque

# Task 1 - Binary Search Tree implementation

class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

# create root node
root = Node(10)
root.left = Node(5)
root.right = Node(15)

# preorder traversal - Root Left Right
def preorder(root):
    if root:
        print(root.value, end=' ')
        preorder(root.left)
        preorder(root.right)

# inorder traversal - Left Root Right
def inorder(root):
    if root:
        inorder(root.left)
        print(root.value, end=' ')
        inorder(root.right)

# postorder traversal - Left Right Root
def postorder(root):
    if root:
        postorder(root.left)
        postorder(root.right)
        print(root.value, end=' ')

# count total number of nodes
def count_nodes(root):
    if root is None:
        return 0
    return 1 + count_nodes(root.left) + count_nodes(root.right)

# find height of tree
def height(root):
    if root is None:
        return 0
    return 1 + max(height(root.left), height(root.right))

# search for a value in the BST
def search_bst(root, val):
    if root is None or root.value == val:
        return root
    if val < root.value:
        return search_bst(root.left, val)
    else:
        return search_bst(root.right, val)

# insert a value into the BST
def insert_bst(root, val):
    if root is None:
        return Node(val)
    if val < root.value:
        root.left = insert_bst(root.left, val)
    else:
        root.right = insert_bst(root.right, val)
    return root

# find minimum value node
def find_min(root):
    current = root
    while current.left:
        current = current.left
    return current

# delete a node from the BST
def delete_node(root, val):
    if root is None:
        return root
    if val < root.value:
        root.left = delete_node(root.left, val)
    elif val > root.value:
        root.right = delete_node(root.right, val)
    else:
        if root.left is None:
            return root.right
        elif root.right is None:
            return root.left
        temp = find_min(root.right)
        root.value = temp.value
        root.right = delete_node(root.right, temp.value)
    return root

# level order traversal using breadth first search
def level_order(root):
    if not root:
        return
    queue = deque([root])
    while queue:
        node = queue.popleft()
        print(node.value, end=' ')
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)

# testing all the methods
print("Preorder:   ", end=''); preorder(root); print()
print("Inorder:    ", end=''); inorder(root); print()
print("Postorder:  ", end=''); postorder(root); print()
print("Level Order:", end=''); level_order(root); print()
print("Node count:", count_nodes(root))
print("Tree height:", height(root))

root = insert_bst(root, 3)
root = insert_bst(root, 7)
root = insert_bst(root, 12)
print("\nAfter inserting 3, 7, 12:")
print("Inorder:", end=' '); inorder(root); print()

result = search_bst(root, 7)
print("\nSearch for 7:", "Found" if result else "Not found")

root = delete_node(root, 5)
print("\nAfter deleting 5:")
print("Inorder:", end=' '); inorder(root); print()
