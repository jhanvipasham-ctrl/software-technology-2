import timeit
import random

# Task 4 - Combining sorting and searching algorithms
# Testing different combinations to see which ones are faster

def linear_search(array, target):
    for i in range(len(array)):
        if array[i] == target:
            return i
    return -1

def binary_search(array, target):
    left = 0
    right = len(array) - 1
    mid = int((left + right) / 2)
    while left <= right:
        if array[mid] == target:
            return mid
        elif target > array[mid]:
            left = mid + 1
        elif target < array[mid]:
            right = mid - 1
        mid = int((left + right) / 2)
    return -1

def insertion_sort(arr):
    for i in range(1, len(arr)):
        current_element = arr[i]
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1
        arr[j + 1] = current_element
    return arr

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr

# generate a random list of 1000 numbers and pick a random target to search for
data = [random.randint(1, 1000) for _ in range(1000)]
target = random.randint(1, 1000)

# test each combination and print how long it takes
# using number=10 means each test runs 10 times so the results are more accurate

# combination 1 - sort with insertion sort first then search with linear search
t = timeit.timeit(lambda: linear_search(insertion_sort(data[:]), target), number=10)
print(f"Insertion Sort + Linear Search:  {t:.6f} seconds")

# combination 2 - sort with bubble sort first then search with linear search
t = timeit.timeit(lambda: linear_search(bubble_sort(data[:]), target), number=10)
print(f"Bubble Sort + Linear Search:     {t:.6f} seconds")

# combination 3 - sort with insertion sort first then use binary search
# binary search needs sorted data so we have to sort it first
t = timeit.timeit(lambda: binary_search(insertion_sort(data[:]), target), number=10)
print(f"Insertion Sort + Binary Search:  {t:.6f} seconds")

# combination 4 - sort with bubble sort first then use binary search
t = timeit.timeit(lambda: binary_search(bubble_sort(data[:]), target), number=10)
print(f"Bubble Sort + Binary Search:     {t:.6f} seconds")

# combination 5 - just linear search on its own with no sorting
# this is our baseline to compare everything else against
t = timeit.timeit(lambda: linear_search(data[:], target), number=10)
print(f"Linear Search only (unsorted):   {t:.6f} seconds")

print("\nDone! Lower time = faster algorithm.")
